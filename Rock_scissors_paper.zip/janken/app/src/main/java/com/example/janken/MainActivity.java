package com.example.janken;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    ImageView[] playerChoice = new ImageView[3];

    ImageView comChoice;

    TextView resultMsg;


    int player;

    int com;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        playerChoice[0] = findViewById(R.id.rock);

        playerChoice[1] = findViewById(R.id.scissors);

        playerChoice[2] = findViewById(R.id.paper);

        resultMsg = findViewById(R.id.resultMsg);


        //Button to reset after a game.
        Button resetButton = findViewById(R.id.Retry);

        resetButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(MainActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });

        for (int i=0; i<playerChoice.length; i++){
            playerChoice[i].setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    letsJanken(view);

                }
            });
        }
         comChoice = findViewById(R.id.imgCpu);
    }
    private void letsJanken(View v){

        ImageView piv = (ImageView) v;

        int pid = piv.getId();


        //Player picks a choice, the other two disappear.
        if(pid == R.id.rock){

            player = 0;
            playerChoice[0].setClickable(false);
            playerChoice[1].setVisibility(View.INVISIBLE);
            playerChoice[2].setVisibility(View.INVISIBLE);
        }
        else if(pid == R.id.scissors){

            player = 1;
            playerChoice[1].setClickable(false);
            playerChoice[0].setVisibility(View.INVISIBLE);
            playerChoice[2].setVisibility(View.INVISIBLE);

        }
        else if(pid == R.id.paper){

            player = 2;
            playerChoice[2].setClickable(false);
            playerChoice[0].setVisibility(View.INVISIBLE);
            playerChoice[1].setVisibility(View.INVISIBLE);

        }
        else{

        }

        //RNG for the computer.
        com = (int)(Math.random()*3);

        int setComImageNum = 0;
        //set computer choice
        if (com == 0) {

            setComImageNum = R.drawable.r_rock;
        }
        else if(com == 1){

            setComImageNum = R.drawable.r_scissors;
        }
        else if(com == 2){

            setComImageNum = R.drawable.r_paper;
        }
        else{

        }
        comChoice.setImageResource(setComImageNum);

        doJudge();

        }
        //Calculate the result of the choices.
        private void doJudge(){

        int diff = player - com;

        if(diff == -1 || diff == 2){
            resultMsg.setText("勝ち");
        }

        else if(diff == 1 || diff == -2){
            resultMsg.setText("負け");
        }

        else if(diff == 0){
            resultMsg.setText("あいこです！");

        }

    }
}
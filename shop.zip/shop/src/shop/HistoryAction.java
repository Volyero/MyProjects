package shop;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.Customer;
import bean.History;
import dao.PurchaseDAO;
import tool.Action;

public class HistoryAction extends Action {
	@SuppressWarnings("unchecked")
	public String execute(
			HttpServletRequest request, HttpServletResponse response
			)throws Exception{
		HttpSession session=request.getSession();
		Customer customer = (Customer)session.getAttribute("customer");
		if(customer==null) {
			return "preview-error-login.jsp";
		}

		String login = customer.getLogin();

		PurchaseDAO dao=new PurchaseDAO();
		List<History> historylist = dao.search(login);

		session.setAttribute("historylist", historylist);
		return "history.jsp";
	}

}

package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import bean.History;
import bean.Item;
import bean.Product;

public class PurchaseDAO extends DAO {
	public boolean insert(List<Item> cart, String name, String address, String login) throws Exception {
		Connection con=getConnection();
		con.setAutoCommit(false);

		for (Item item : cart) {
			PreparedStatement st=con.prepareStatement(
				"insert into purchase values(null, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, ?)");
			Product p=item.getProduct();
			st.setInt(1, p.getId());
			st.setString(2, p.getName());
			st.setInt(3, p.getPrice());
			st.setInt(4, item.getCount());
			st.setString(5, name);
			st.setString(6, address);
			st.setString(7, login);
			int line=st.executeUpdate();
			st.close();

			if (line!=1) {
				con.rollback();
				con.setAutoCommit(true);
				con.close();
				return false;
			}
		}

		con.commit();
		con.setAutoCommit(true);
		con.close();
		return true;
	}
	public List<History>search(String login)throws Exception{
		List<History>historylist=new ArrayList<>();
		Connection con=getConnection();
		con.setAutoCommit(false);

		PreparedStatement st=con.prepareStatement(
				"select * from purchase where(loginuser=?)");
		st.setString(1, login);
		ResultSet rs=st.executeQuery();

		while (rs.next()) {
			History h = new History();
			h.setId(rs.getInt("id"));
			h.setproduct_id(rs.getInt("product_id"));
			h.setproduct_name(rs.getString("product_name"));
			h.setproduct_price(rs.getInt("product_price"));
			h.setproduct_count(rs.getInt("product_count"));
			h.setcustomer_name(rs.getString("customer_name"));
			h.setcustomer_address(rs.getString("customer_address"));
			h.setpurchase_date(rs.getDate("purchase_date"));
			h.setloginuser(rs.getString("loginuser"));

			historylist.add(h);
		}
		st.close();
		con.close();
		return historylist;
	}
}

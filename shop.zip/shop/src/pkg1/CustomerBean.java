package pkg1;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Customer;
import tool.Page;

@WebServlet(urlPatterns= {"/pkg1/CustomerBean"})
public class CustomerBean  extends HttpServlet{
	public void doGet(
			HttpServletRequest request, HttpServletResponse response
			) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		Page.header(out);

		Customer c = new Customer();

		c.setId(1);
		c.setLogin("ayukawa");
		c.setPassword("SweetfishRiver1");

		out.println(c.getId());
		out.println(":");
		out.println(c.getLogin());
		out.println(":");
		out.println(c.getPassword());

		Page.footer(out);
	}

}

package bean;

import java.util.Date;

public class History implements java.io.Serializable {

	private int id;
	private int product_id;
	private String product_name;
	private int product_price;
	private int product_count;
	private String customer_name;
	private String customer_address;
	private Date purchase_date;
	private String loginuser;
	//getter

	public int getId() {
		return id;
	}
	public int getproduct_id() {
		return product_id;
	}
	public String getproduct_name() {
		return product_name;
	}
	public int getproduct_price() {
		return product_price;
	}
	public int getproduct_count() {
		return product_count;
	}
	public String getcustomer_name() {
		return customer_name;
	}
	public String getcustomer_address() {
		return customer_address;
	}
	public Date getpurchase_date() {
		return purchase_date;
	}
	public String getloginuser() {
		return loginuser;
	}
	//setter

	public void setId(int id) {
		this.id=id;
	}
	public void setproduct_id(int product_id) {
		this.product_id=product_id;
	}
	public void setproduct_name(String product_name) {
		this.product_name=product_name;
	}
	public void setproduct_price(int product_price) {
		this.product_price=product_price;
	}
	public void setproduct_count(int product_count) {
		this.product_count=product_count;
	}
	public void setcustomer_name(String customer_name) {
		this.customer_name=customer_name;
	}
	public void setcustomer_address(String customer_address) {
		this.customer_address=customer_address;
	}
	public void setpurchase_date(Date purchase_date) {
		this.purchase_date=purchase_date;
	}
	public void setloginuser(String loginuser) {
		this.loginuser=loginuser;
	}
	}

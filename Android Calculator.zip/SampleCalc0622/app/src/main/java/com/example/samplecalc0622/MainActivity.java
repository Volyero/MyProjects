package com.example.samplecalc0622;

import androidx.appcompat.app.AppCompatActivity;


import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    //フィールド変数（メンバ変数）
    //表示領域の部品（TextView）を宣言

    TextView tv;
    TextView tv2;

    int wkNum;
    int wkNum2;

    boolean opFlg = false;

    String opCode = "";



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        //表示領域(TextView)をインスタンス化
        tv = findViewById(R.id.outputArea);
        tv2 = findViewById(R.id.inputArea);
        //クリアボタンのインスタンス化
        Button clearBtn = findViewById(R.id.clear);
        clearBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {tv.setText("0"); tv2.setText("0");}
        });
        //ぼたんく
        Button[] opSymbol = new Button[5];
        opSymbol[0] = findViewById(R.id.plus);
        opSymbol[1] = findViewById(R.id.minus);
        opSymbol[2] = findViewById(R.id.multiply);
        opSymbol[3] = findViewById(R.id.divide);
        opSymbol[4] = findViewById(R.id.plusminus);


        for(int i=0; i< opSymbol.length; i++){
            opSymbol[i].setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    opClicked(view);
                }
            });
        }



        Button equalBtn = findViewById(R.id.equal);
        equalBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                calculate();
            }
        });

        Button backspaceBtn = findViewById(R.id.backspace);
        backspaceBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String str=tv.getText().toString();
                if(str.length()>=1){
                    str = str.substring(0, str.length()-1);
                    tv.setText(str);
                };
                if (str.length()<1){
                    tv.setText("0");
                }
            }
        });

        Button dotBtn = findViewById(R.id.dot);
        dotBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                tv.setText(tv.getText().toString() + ".");
            }
        });



        //ボタン(数直)0-9の変数を配列として宣言
        Button[] numBtn = new Button[10];
        numBtn[0] = findViewById(R.id.zero);
        numBtn[1] = findViewById(R.id.one);
        numBtn[2] = findViewById(R.id.two);
        numBtn[3] = findViewById(R.id.three);
        numBtn[4] = findViewById(R.id.four);
        numBtn[5] = findViewById(R.id.five);
        numBtn[6] = findViewById(R.id.six);
        numBtn[7] = findViewById(R.id.seven);
        numBtn[8] = findViewById(R.id.eight);
        numBtn[9] = findViewById(R.id.nine);

        //ボタンクリックのイベントを受け取るリスナー10回ループ
        for(int i=0; i<10; i++) {

            numBtn[i].setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    displayNumber(view);

                }

            });
        }

    }
    private void opClicked(View v){
        opFlg = true;
        Button btn = (Button) v;
        opCode = btn.getText().toString();
        plusminus();
    }


    private int calculate(){

        String strNum = tv.getText().toString();
        int wkNum2 = Integer.parseInt(strNum);
        int answer = 0;

        if (opCode.equals("+")) {
            answer = wkNum + wkNum2;
        }   else if(opCode.equals("－")){
            answer = wkNum - wkNum2;
        }   else if(opCode.equals("×")){
            answer = wkNum * wkNum2;
        }   else if(opCode.equals("÷")){
            answer = wkNum / wkNum2;
        }
        tv2.setText(String.valueOf(answer));
        return answer;

    }

    private void plusminus(){
        String strNum = tv2.getText().toString();
        int wkNum2 = Integer.parseInt(strNum);
        int answer = wkNum2;
        if(opCode.equals("±")){
            answer = wkNum2 * (-1);
        }
        tv2.setText(String.valueOf(answer));

        String strNum1 = tv.getText().toString();
        int wkNum = Integer.parseInt(strNum1);
        int answer1 = wkNum;
        if(opCode.equals("±")){
            answer1 = wkNum * (-1);
        }
        tv.setText(String.valueOf(answer1));
    }

    private void init() {
        tv.setText("0");
    }
    private void displayNumber(View v){
        //ボタン型へ変更
        Button btn = (Button) v;
        //ボタンに表示されている数字を取得する
        String str = btn.getText().toString();
        //①「表示されている数値」と②「押されたボタンの計算処理」
        if(!opFlg) {
            //②数字を数値に変換する
            int dNum = Integer.parseInt(str);
            //①表示領域に表示されている数値を取得
            String tvStr = tv.getText().toString();
            //①数字を数値に変換する
            int tvNum = Integer.parseInt(tvStr);

            int num = tvNum * 10 + dNum;
            tv.setText(String.valueOf(num));
            wkNum2 = num;
        } else {

            String tvStr = tv.getText().toString();
            wkNum = Integer.parseInt(tvStr);

            tv.setText(str);
            opFlg = false;

        }
    }
}
